class InvalidURLError(Exception):
    """Raises when an invalid URL string is passed."""
    pass


